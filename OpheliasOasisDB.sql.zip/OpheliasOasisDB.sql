-- phpMyAdmin SQL Dump
-- version 3.3.9.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 17, 2011 at 03:32 PM
-- Server version: 5.5.9
-- PHP Version: 5.3.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `OpheliasOasis`
--

-- --------------------------------------------------------

--
-- Table structure for table `Customer`
--

CREATE TABLE `Customer` (
  `customerID` int(11) NOT NULL AUTO_INCREMENT,
  `firstName` varchar(15) NOT NULL,
  `lastName` varchar(15) NOT NULL,
  `address` varchar(50) NOT NULL,
  `phone` varchar(14) NOT NULL,
  `email` varchar(30) NOT NULL,
  `creditNumber` int(11) DEFAULT NULL,
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`customerID`),
  UNIQUE KEY `username_UNIQUE` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `Customer`
--

INSERT INTO `Customer` VALUES(1, 'Adam', 'Ford', '1234 lollipop lane', '1234567890', '', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Employee`
--

CREATE TABLE `Employee` (
  `employeeID` int(11) NOT NULL AUTO_INCREMENT,
  `firstName` varchar(15) NOT NULL,
  `middleName` varchar(15) NOT NULL,
  `lastName` varchar(15) NOT NULL,
  `employeeType` varchar(50) NOT NULL,
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`employeeID`),
  UNIQUE KEY `username_UNIQUE` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `Employee`
--

INSERT INTO `Employee` VALUES(1, 'Adam', 'J.', 'Ford', 'manager', 'aford1', 'password');
INSERT INTO `Employee` VALUES(2, 'test', 'test', 'test', 'manager', 'test', NULL);
INSERT INTO `Employee` VALUES(3, 'Bud', '', 'Jones', 'manager', 'bud', 'password');

-- --------------------------------------------------------

--
-- Table structure for table `Reservation`
--

CREATE TABLE `Reservation` (
  `reservationID` int(11) NOT NULL AUTO_INCREMENT,
  `dateofReservation` date NOT NULL,
  `arrivingDate` date NOT NULL,
  `departureDate` date NOT NULL,
  `reservationType` varchar(30) DEFAULT NULL,
  `roomID` int(11) NOT NULL,
  `firstName` varchar(30) NOT NULL,
  `lastName` varchar(30) NOT NULL,
  `address` varchar(30) NOT NULL,
  `city` varchar(30) NOT NULL,
  `state` varchar(30) NOT NULL,
  `country` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `phone` int(10) DEFAULT NULL,
  `cardType` varchar(30) NOT NULL,
  `cardNumber` int(11) NOT NULL,
  `expirationMonth` int(11) NOT NULL,
  `expirationYear` int(11) NOT NULL,
  PRIMARY KEY (`reservationID`),
  KEY `Reservation_FK` (`roomID`),
  KEY `roomID` (`roomID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `Reservation`
--

INSERT INTO `Reservation` VALUES(1, '2011-11-15', '2011-11-15', '2011-11-16', 'conventional', 1, 'Adam', 'Ford', '1234 test avenue', 'Honolulu', 'Hawaii', 'United States', 'aford1@my.hpu.edu', 2147483647, 'visa', 2147483647, 1, 2011);
INSERT INTO `Reservation` VALUES(2, '2011-11-15', '2011-11-15', '2011-11-17', 'conventional', 2, 'Adam', 'Ford', '1234 test avenue', 'Honolulu', 'Hawaii', 'United States', 'aford1@my.hpu.edu', 2147483647, 'visa', 2147483647, 1, 2011);
INSERT INTO `Reservation` VALUES(3, '2011-11-15', '2011-11-17', '2011-11-19', 'conventional', 3, 'Fred', 'Durst', '1234 test avenue', 'Honolulu', 'Hawaii', 'United States', 'aford1@my.hpu.edu', 2147483647, 'visa', 2147483647, 1, 2011);
INSERT INTO `Reservation` VALUES(4, '2011-11-15', '2011-11-14', '2011-11-16', 'conventional', 3, 'Mayor', 'West', '1234 test avenue', 'Honolulu', 'Hawaii', 'United States', 'aford1@my.hpu.edu', 2147483647, 'visa', 2147483647, 1, 2011);
INSERT INTO `Reservation` VALUES(5, '2011-11-15', '2011-11-14', '2011-11-16', 'conventional', 4, 'Peter', 'Griffin', '1234 test avenue', 'Honolulu', 'Hawaii', 'United States', 'aford1@my.hpu.edu', 2147483647, 'visa', 2147483647, 1, 2011);
INSERT INTO `Reservation` VALUES(6, '2011-11-15', '2011-11-15', '2011-11-16', 'conventional', 5, 'Chris', 'Griffin', '1234 test avenue', 'Honolulu', 'Hawaii', 'United States', 'aford1@my.hpu.edu', 2147483647, 'visa', 2147483647, 1, 2011);

-- --------------------------------------------------------

--
-- Table structure for table `Room`
--

CREATE TABLE `Room` (
  `roomID` int(11) NOT NULL AUTO_INCREMENT,
  `baseRate` varchar(5) NOT NULL,
  `status` varchar(50) NOT NULL,
  PRIMARY KEY (`roomID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `Room`
--

INSERT INTO `Room` VALUES(1, '100.0', 'ready');
INSERT INTO `Room` VALUES(2, '100.0', 'ready');
INSERT INTO `Room` VALUES(3, '100.0', 'ready');
INSERT INTO `Room` VALUES(4, '100.0', 'ready');
INSERT INTO `Room` VALUES(5, '100.0', 'ready');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Reservation`
--
ALTER TABLE `Reservation`
  ADD CONSTRAINT `roomID` FOREIGN KEY (`roomID`) REFERENCES `Room` (`roomID`) ON DELETE NO ACTION ON UPDATE NO ACTION;
